%andADALINEexample

%Training Set for OR function:

%Input Patterns:
P = [ 0 0 1 1;  ...
      0 1 0 1];
%Target Patterns:
T = [0 0 0 1];

%Plot Training Set.
plotpv(P,T);

%Convert data to sequential cell array repeated several times and train the
%network:
PP = repmat(con2seq(P),1,1);
TT = repmat(con2seq(T),1,1);

%Configure ADALINE to the data, with initial weights set to 0:
net = linearlayer;
net = configure(net,P,T);

%Train for one epoch at a time to illustrate progressive learning.
net.trainParam.epochs = 50;

%Don't show training window.
net.trainParam.showWindow = 0;

%Train one epoch at a time and display decision boundary at every step.
i = 0;
continueTraining = 1;
while continueTraining
    i = i + 1;
    clf;
    plotpv(P,T);
    title(['Iteration #',num2str(i)]);
    net = train(net,PP,TT);
    myplotac(net.IW{1},net.b{1});
    continueTrainingInput = input('Continue training? (0/1): '); 
    if ischar(continueTrainingInput)
        continueTraining = 1;
    elseif continueTrainingInput == 0
        continueTraining = 0;
    end;
end;

%Plot test vectors to see if ADALINE classifies correctly:
continueClassifying = 1;
while continueClassifying
    xInput = input('Test vector ([num num], stop = <return>):');
    if isempty(xInput)
        break;
    end;
    x = xInput';
    y = net(x);
    plotpv(x+.0075,round(y));
%     plotpv(x,round(y));
    point = findobj(gca,'type','line');
    set(point,'Color','red');
    hold on;
    plotpv(P,T);
    myplotac(net.IW{1},net.b{1});
    hold off;
    disp(['Classification: ',num2str(y)]);
end;
