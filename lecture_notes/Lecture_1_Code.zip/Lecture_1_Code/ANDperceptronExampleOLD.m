%andPerceptronExample

%Training Set for AND function:
P =  {[0;0] [0;1] [1;0] [1;1]};
T =  {0 0 0 1};

%Rx2 matrix of min/max values for R input elements:
PR = [0,1;0,1];

%Number of Neurons:
S = 1;

%Transfer function 'hardlim' (default), or 'hardlims'
TF = 'hardlim';

%Learning Function 'learnp' or 'learnpn'
LF = 'learnp';

%Define Perceptron and Initialize:
net = newp(PR,S,TF,LF);
net = init(net);

Y0 = sim(net,P);

net.trainParam.epochs = 20;
net = adapt(net,P,T);

Y = sim(net,P);
