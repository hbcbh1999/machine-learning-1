%XORMultiADALINEExample

%Training Set for OR, AND, and NAND functions:

%Input Patterns:
P = [ 0 0 1 1;  ...
      0 1 0 1];

%Targets (XOR):
T = [0 1 1 0];
  
%OR Targets:
T_OR = [0 1 1 1];

%AND Targets:
T_AND = [0 0 0 1];

%NAND Targets:
T_NAND = [1 1 1 0];

%Convert data to sequential cell arrays repeated several times and train the
%networks:
PP = repmat(con2seq(P),1,1);

TT_OR = repmat(con2seq(T_OR),1,1);
TT_AND = repmat(con2seq(T_AND),1,1);
TT_NAND = repmat(con2seq(T_NAND),1,1);

%Plot Training Set.
plotpv(P,T);

%Configure OR ADALINE to the data, with initial weights set to 0:
ORnet = linearlayer;
ORnet = configure(ORnet,P,T_OR);

%Configure AND ADALINE to the data, with initial weights set to 0:
ANDnet = linearlayer;
ANDnet = configure(ANDnet,P,T_AND);

%Configure NAND ADALINE to the data, with initial weights set to 0:
NANDnet = linearlayer;
NANDnet = configure(NANDnet,P,T_NAND);

%Train for one epoch at a time to illustrate progressive learning.
ORnet.trainParam.epochs = 25;
ANDnet.trainParam.epochs = 25;
NANDnet.trainParam.epochs = 25;

%Don't show training window.
ORnet.trainParam.showWindow = 0;
ANDnet.trainParam.showWindow = 0;
NANDnet.trainParam.showWindow = 0;

%Train one epoch at a time and display decision boundary at every step.
i = 0;
continueTraining = 1;
while continueTraining
    i = i + 1;
    clf;
    plotpv(P,T);
    title(['Iteration #',num2str(i)]);
    ORnet = train(ORnet,PP,TT_OR);
    ANDnet = train(ANDnet,PP,TT_AND);
    NANDnet = train(NANDnet,PP,TT_NAND);
    myplotac(ORnet.IW{1},ORnet.b{1}); 
    myplotac(NANDnet.IW{1},NANDnet.b{1},'n');
    continueTrainingInput = input('Continue training? (0/1): '); 
    if ischar(continueTrainingInput)
        continueTraining = 1;
    elseif continueTrainingInput == 0
        continueTraining = 0;
    end;
end;

%Plot a test vector to see if it classifies correctly:
continueClassifying = 1;
while continueClassifying
    xInput = input('Test vector ([num num], stop = <return>):');
    if isempty(xInput)
        break;
    end;
    x = xInput';
    y_OR = round(ORnet(x));
    y_NAND = round(NANDnet(x));
    y = ANDnet([y_OR;y_NAND]);
    plotpv(x+.0075,round(y));
    point = findobj(gca,'type','line');
    set(point,'Color','red');
    hold on;
    
    plotpv(P,T);
    myplotac(ORnet.IW{1},ORnet.b{1}); 
    myplotac(NANDnet.IW{1},NANDnet.b{1},'n');
    hold off;
    disp(['Classification: ',num2str(y)]);
end;