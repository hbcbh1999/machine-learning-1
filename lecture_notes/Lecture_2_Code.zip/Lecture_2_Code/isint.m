function b = isint(x)
% IS INTEGER (custom) Given x, determines whether it is an integer. If x is a vector or array,
%                     returns 1 if all of its elements are integers.
%
% x = A number or array.
%
%RETURNS:
%
% b = A Boolean = 1 if all of the elements of x are integers, 0 otherwise.
%  
%USAGE:
%
%      b = isint(x);
%

%Miguel Castro
%Version 1
%January 19, 2006

b = 0;

if ~isnumeric(x)
    return;
end;

x = x(:);

d = ceil(x) == floor(x);

if sum(d) == length(x)
    b = 1;
end;



