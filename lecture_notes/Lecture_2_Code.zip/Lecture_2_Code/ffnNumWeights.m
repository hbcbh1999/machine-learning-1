function numWeights = ffnNumWeights(numInputs,numOutputs,H1,varargin)
%FFN NUMBER OF WEIGHTS: Figures out number of weights of an FFN given
%                       the numInputs, numOutputs, H1, H2,...
%
% numWeights = ffnNumWeights(numInputs,numOutputs,H1,*H2,*H3,...);
%

%20110907

numOptionalInputArgs = nargin - 3;

numHiddenLayers = numOptionalInputArgs + 1;

HL = zeros(1,numHiddenLayers);

HL(1) = H1;

if numHiddenLayers > 1
    for j = 2:numHiddenLayers
        HL(j) = varargin{j-1};
    end;
end;

numWeights = (numInputs + 1)*HL(1) + (HL(end) + 1)*numOutputs;

if numHiddenLayers > 1
    for j = 1:numHiddenLayers - 1
        numWeights = numWeights + (HL(j) + 1)*HL(j+1);
    end;
end;