function plotBinomial(R,N,gridSize)
% PLOTBINOMIAL Plots unnormalized binomial distribution given number of Heads, number of tosses, and a gridSize.
%
% R = Number of Heads.
% N = Number of Tosses.
% gridSize = Size of grid to plot (max(1000,N) recommended).
%
% RETURNS: Plot of H^R*(1-H)^(N-R).
%
% USAGE: plotBinomial(27,100,1000);

% Miguel Castro
% Version 1
% September 11, 2013

if ~(isint(R) && isint(N) && isint(gridSize) && R >= 0 && N >= 0 && gridSize > 0)
    error('Inputs must be positive integers.');
end;

if R > N
    error('R cannot exceed N.');
end;

if gridSize < N
    error('gridSize too small compared to N.');
end;

gridStep = 1/gridSize;

H = 0:gridStep:1;

B = zeros(gridSize+1,1);

for h = 1:gridSize + 1
    B(h) = H(h)^R*(1 - H(h))^(N-R);
end;

%Normalization:
B = nchoosek(N,R)*B;

sum(B)

figure;
[hAx,hline1,hline2] = plotyy(H,B,H,ones(size(H)));
set(hline1,'Color','b');
set(hline2,'Color','r');
axis(hAx(1),[0,1,0,.4]);
axis(hAx(2),[0,1,0,1.2]);
% set(hline2,'LineStyle','--');
xlabel('H: Bias Towards Heads (Unbiased = 0.5)');
ylabel(hAx(1),'Posterior P(H|data,I)');
ylabel(hAx(2),'Prior P(H|I=\0)','Color','r');
title([num2str(R),' heads out of ',num2str(N),' tosses']);

    
