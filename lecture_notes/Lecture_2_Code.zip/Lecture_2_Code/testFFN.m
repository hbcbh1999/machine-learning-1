%testFFN

%Number of Hidden Nodes in Hidden Layer 1:
numHN1 = 20;

%Transfer Function for Hidden Layer 1:
HL1TransferFcn = 'tansig';
% HL1TransferFcn = 'satlins';
% HL1TransferFcn = 'purelin';
% HL1TransferFcn = 'poslin';
% HL1TransferFcn = 'radbas';
% HL1TransferFcn = 'radbasn';
% HL1TransferFcn = 'tribas';

%Transfer Function for Output Layer:
OLTransferFcn = 'purelin';

%Number of test data points:
N = 5000;

%Number of std devs in noise:
Nsigma = 1;

%Data range (x-axis):
xMin = -10;
xMax = 10;

%Generate the test data:
[x,y,yp,R2max] = createTestData(xMin,xMax,N,Nsigma,1);

%Convert data to sequential cell array:
PP = repmat(con2seq(x),1,1);
TT = repmat(con2seq(y),1,1);
TTp = repmat(con2seq(yp),1,1);

%Configure FFN to the data, with initial weights set to 0:
%myNet = makeFFN([10,5,...],HLTransferFcn,OLTransferFcn);
myNet = makeFFN([numHN1],HL1TransferFcn,OLTransferFcn);
myNet = configure(myNet,x,y);

%Training Function:
myNet.trainFcn = 'trainlm';
% myNet.trainFcn = 'trainbr';

%Max number of epochs:
myNet.trainParam.epochs = 500;

%Show Training Window?
myNet.trainParam.showWindow = 0;

%Train network:
% [myNet,tr] = train(myNet,PP,TT);
% [myNet,tr] = train(myNet,PP,TT,'useParallel','yes');
% [myNet,tr] = train(myNet,PP,TT,'useParallel','yes','useGPU','yes');

%Train network:
% [myNet,tr] = train(myNet,PP,TTp);
[myNet,tr] = train(myNet,PP,TTp,'useParallel','yes');
% [myNet,tr] = train(myNet,PP,TTp,'useParallel','yes','useGPU','yes');

%Plot network output:
yOut = myNet(x);

figure;
plot(x,yp,'r');
hold on;
plot(x,y,'k');
plot(x,yOut,'b');
title('Test Function');
legend('Target',['[',num2str(numHN1),'] Hidden Nodes']);
xlabel('x');
ylabel('y');
hold off;

figure;
plotperform(tr);

figure;
plotregression(y,yOut);


