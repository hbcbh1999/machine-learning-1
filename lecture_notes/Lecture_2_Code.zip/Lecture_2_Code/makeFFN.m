function myNet = makeFFN(H,varargin)
% MAKEFFN Generates a Feed-Forward network given a vector L containing the sizes
% of each hidden layer and output layer and, optionally, the hidden-layer activations 
% (or transfer) functions and the output activations. If viewNet, view net topology.
%
% H = Vector with length = number of hidden layers, containing the size of each hidden layer.
%
% HLTransferFcn *optional* = Transfer function for the Hidden Layer(s). Defaults to 'tansig'.
%
% OLTransferFcn *optional* = Transfer function for the Output Layer. Defaults to 'purelin'.
%
% RETURNS: myNet, the configured network object.
%
% USAGE: myNet = makeFFN([10,5,...]);
%        myNet = makeFFN([10,5,...],HLTransferFcn);
%        myNet = makeFFN([10,5,...],HLTransferFcn,OLTransferFcn);
%
% LIST OF TRANSFER FUNCTIONS:
% -------------------------------------------
% 'compet'      Competitive 
% 'elliotsig'   Elliot symmetric sigmoid
% 'elliot2sig'  Elliot 2 symmetric sigmoid
% 'hardlim'     Hard-limit 
% 'hardlims'    Symmetric hard-limit 
% 'logsig'      Log-sigmoid 
% 'netinv'      Inverse 
% 'poslin'      Positive linear 
% 'purelin'     Linear 
% 'radbas'      Radial basis 
% 'radbasn'     Normalized radial basis 
% 'satlin'      Saturating linear 
% 'satlins'     Symmetric saturating linear 
% 'softmax'     Soft Max 
% 'tansig'      Hyperbolic tangent sigmoid 
% 'tribas'      Triangular basis 
% -------------------------------------------

% Miguel Castro
% Version 1
% September 03, 2013

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%For class illustration purposes only (net architecture graphic). Comment if
%desired:
fakeInputs = [1 2];
fakeOutputs = [1 2];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

AvailableTransferFcns = { 'compet' 'elliotsig' 'hardlim' 'hardlims' 'logsig' 'netinv' 'poslin' 'purelin' ...
                          'radbas' 'radbasn' 'satlin' 'satlins' 'softmax' 'tansig' 'tribas' };


num_opt_input_vars = length(varargin);  %Get the number of optional input variables.

if num_opt_input_vars > 2
    error('There can be at most two optional input variables.');
end;

if num_opt_input_vars == 0
    HLTransferFcn = 'tansig';
    OLTransferFcn = 'purelin';
elseif num_opt_input_vars == 1
    HLTransferFcn = varargin{1};
    OLTransferFcn = 'purelin';
    if ~ischar(HLTransferFcn)
        error('First optional input HLTransferFcn must be a character string.');
    elseif ~ismember(HLTransferFcn,AvailableTransferFcns)
        error(['Transfer function ''',HLTransferFcn,''' not found.']);
    end;
else
    HLTransferFcn = varargin{1};
    OLTransferFcn = varargin{2};
    if ~ischar(HLTransferFcn)
        error('First optional input HLTransferFcn must be a character string.');
    elseif ~ismember(HLTransferFcn,AvailableTransferFcns)
        error(['Transfer function ''',HLTransferFcn,''' not found.']);
    end;
    if ~ischar(OLTransferFcn)
        error('Second optional input OLTransferFcn must be a character string.');
    elseif ~ismember(OLTransferFcn,AvailableTransferFcns)
        error(['Transfer function ''',OLTransferFcn,''' not found.']);
    end;
end;

H = H(:)';

numHiddenLayers = length(H);

if ~isint(H) || sum(H > 0) ~= numHiddenLayers
    error('All entries in H must be positive integers.');
end;

myNet = feedforwardnet(H);

for i = 1:numHiddenLayers
    myNet.layers{i}.transferFcn = HLTransferFcn;
end;

myNet.layers{numHiddenLayers+1}.transferFcn = OLTransferFcn;

%Display Network Architecture (with correct input/output size if desired):
if exist('fakeInputs','var')
    myNet = configure(myNet,fakeInputs,fakeOutputs);
end;
view(myNet);

end

