function r = randInterval(a,b,N)
%RANDINTERVAL (custom) Generates N uniform random numbers in the interval 
%                      [a,b].
%a = The start (lower bound) of the interval (numeric).
%b = The end (upper bound) of the interval (numeric).
%N = The number of uniform random numbers to generate.
%
%RETURNS: 
%
% r = A 1xN ROW vector with N random numbers in the interval [a,b] drawn from a
%     Uniform Distribution.
%
%USAGE:
%       r = randInterval(a,b,N);
%       
%

%Miguel Castro
%Version 1.
%March 29, 2015    


if ~isnumeric(a) || ~isnumeric(b) || ~isint(N)
    error('All inputs must be numeric and N must be an integer.');
end;

if a >= b
    error('b must be greater than a.');
end;

r = a + (b - a)*rand(1,N);
      