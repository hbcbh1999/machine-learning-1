function [x,y,yp,R2max] = createTestData(xMin,xMax,N,Nsigma,plotFig)
%CREATETESTDATA Generates test data from a relatively complicated
%               combination of sinusoidal functions and corrupts it
%               with Gaussian noise with Nsigma std devs. Optionally
%               plots both the uncorrupted and corrupted test data.
%               Also computes the theoretically maximum R-Squared.
%
% xMin = The minimum x value of the data range.
% xMax = The maximum x value of the data range.
% N = The total number of test data points.
% Nsigma = The number of standard deviations the noise will have. (Here 
%          the standard deviation is just the std dev of the uncorrupted 
%          data.)
%
% RETURNS: x = The x data (abscissae). 
%          y = The uncorrupted y data (ordinates).
%          yp = The corrupted y data.
%          R2max = The theoretically maximum R-Squared.
%
% USAGE: [x,y,yp,R2max] = createTestData(xMin,xMax,N,Nsigma,plotFig);
%

% Miguel Castro
% Version 1
% September 07, 2011

inc = (xMax - xMin)/N;

x = xMin:inc:xMax;

y = 1.5*cos(.5*pi*x) - sin(.3*pi*x) + .7*cos(.7*pi*x) + .3*sin(.8*pi*x);

yp = y + Nsigma*std(y)*randn(size(y));

ypAvg = mean(yp);

SStotal = (yp - ypAvg)*(yp - ypAvg)';

SSresidual = (yp - y)*(yp - y)';

R2max = 1 - SSresidual/SStotal;

if plotFig
    figure;
    plot(x,y,'k');
    figure;
    hold on;
    plot(x,yp,'r');
    plot(x,y,'k');
    hold off;
end;

